<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller {
	
	public function __construct() 
	{
		parent::__construct();
		$this -> load -> model('article_model');
		$this -> load -> model('tag_model');
		header('content-type:text/html; charset=utf-8');
	}
	
	public function index() {
		$articles = $this -> article_model -> get_five_articles();
		$five_tags = $this -> tag_model -> get_five_tags();
		$data = array(
			"articles" => $articles,
			"five_tags" => $five_tags
		);
		$this -> load -> view('index', $data);
	}
	
	public function articles($article_id){
		
		$article = $this -> article_model -> get_article_by_article_id($article_id);
		$article_tags = $this -> tag_model -> get_tags_by_article_id($article_id);
		$data = array(
			"article" => $article,
			"article_tags" => $article_tags
		);
		$this -> load -> view("articles", $data);
	}
	public function tas($tags_id){
		$articles = $this -> article_model -> get_articles_by_tag_id($tag_id);
		$this -> load -> view("tags", array(
			"articles" => $articles
		));
		
	}
	
	public function zan(){
		$article_id = $this -> input -> get("article_id");
		$row = $this -> article_model -> zan($article_id);
		if($row){
			echo "success";
		} else{
			echo "fail";
		}
	}
	
}