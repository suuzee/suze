<div class="header">
	<ul class="top-nav">
		<li class="active"><a href="#">我的文章</a></li>
		<li><a href="#">热门文章</a></li>
		<li><a href="#">关于我</a></li>
	</ul>
	<form action="search" class="search" method="post">
		<input type="text" class="search-text" placeholder="在这里搜索" />
		<button type="submit" class="search-btn" value=""><i class="fa fa-search"></i></button>
	</form>
</div>