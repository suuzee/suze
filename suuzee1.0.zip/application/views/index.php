<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>SU_ZE__' Blog</title>
        <link rel="stylesheet" href="assets/front/css/style.css" />
        <link rel="stylesheet" href="assets/front/css/index.css" />
        <link rel="stylesheet" href="assets/front/css/font-awesome.min.css" />
        <link rel="shortcut icon" href="assets/front/img/favicon.ico" />
    </head>
    <body>
        <?php include("sidebar.php");?>
        <div class="container">
            <?php include("header.php");?>
            <div class="article-list">
                <ul class="tags">
                    <li class="active"><a href="#">ALL</a></li>
                    <?php
                    	foreach($five_tags as $five_tag){
                    ?>
                    	<li><a href="tags/<?php echo $five_tag -> tag_id;?>"><?php echo $five_tag -> tag_name;?></a></li>
                    <?php
						}
                    ?>
                </ul>
                <ul class="blog-list">
                	<?php
                		foreach($articles as $article){
                			$this -> load -> model("tag_model");
                	?>
		                    <li class="blog-item">
		                        <a href="articles/<?php echo $article -> article_id;?>" class="blog-title">
		                            <?php echo $article -> article_title;?>
		                        </a>
		                        <a href="articles/<?php echo $article -> article_id;?>" class="blog-content">
		                            <?php echo $article -> article_content;?>
		                        </a>
		                        <div class="blog-info">
		                            <div class="blog-time"><?php echo $article -> article_date;?></div>
			                            <?php
											$tags = $this -> tag_model -> get_tags_by_article_id($article -> article_id);
			                            	if(count($tags) != 0 ){
												foreach($tags as $tag){
										?>
			                            			<a href="tags/<?php echo $tag -> tag_id;?>" class="blog-tags" ><?php echo $tag -> tag_name;?></a>
			                            <?php
												}
											}
			                            ?>
		                        </div>
		                    </li>
                    <?php
						}
                    ?>
                </ul>
                <?php
                	if(count($articles) >= 5 ){
                ?>
                	<button type="" class="blog-more" >点击查看更多</button>
                <?php
                	} else{
				?>	
					<button type="" class="blog-more" >更多内容敬请期待</button>
				<?php
                	}
                ?>
            </div>
        </div>
        <div class="footer">
            <ul class="links">
                <li>友情链接：</li>
                <li><a href="http://blog.csdn.net/gdl116929569" target="blank">GDL的小站</a></li>
                <li><a href="http://www.liminghang.cn" target="blank" >李明航的小站</a></li>
            </ul>
            <div class="copyright">
                Copyright &copy; 2015 <a href="http://www.suuzee.cn" target="blank">SU_ZE__' Blog</a> | <a href="http://www.miitbeian.gov.cn/" target="blank">黑ICP备15001607号</a>
            </div>
            <div class="follow">
                关注我： <a href="http://weibo.com/2315975171" target="blank"><i class="fa fa-weibo"></i></a>&nbsp;
                <button><i class="fa fa-weixin"></i></button>
            </div>
        </div>
        <script src="assets/front/js/jquery-1.11.2.min.js"></script>
        <script src="assets/front/js/common.js"></script>
        <script>
            $(function(){
                var someHeight = $(".article-list").css("height");
                $(".rightbar").height((parseInt(someHeight) + 51) + "px");
            });
        </script>
    </body>
</html>