<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>测试文章 - SU_ZE__</title>
        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" href="css/font-awesome.min.css" />
        <link rel="stylesheet" href="css/single.css" />
        <link rel="shortcut icon" href="img/favicon.ico" />
        <link rel="stylesheet" href="prettify/prettify.css" />
    </head>
    <body>
        <?php include("sidebar.php");?>
        <div class="container" >
            <?php include("header.php");?>
            <div class="article">
                <h1 class="article-title">测试文章</h1>
                <p class="article-info">
                    <span class="article-time">2015-3-26 12:00</span>
                    &nbsp;
                    <span>2&nbsp;次阅读</span>
                </p>
                <p class="article-content">
                    海子的诗读的不多，是我听赵雷的南方姑娘也关注一席，刚好那天出了一期赵雷和大冰的《赶着音乐放牧》深深的感动一把继续找马，然后在今天遇到了简书上的和尚，以梦为马就是这么出现在了百度的搜索框里。其实很多事情都是很有串联性的，就好比你来到这里一样。<br /><br />

如果想记录一件事情，必须要了解他。海子大家都知道，卧轨的诗人。面朝大海，春暖花开。一般的人驻足在这些事情上就够了。当你一个人久了你会发现日子很无聊，读书不知为何，文字像空气一样穿过你的身体，最后还只是为了生存下去。我一定会很喜欢海子的，从以梦为马（祖国）的头两句，我就知道他一定可以带我光明。<br /><br />
 我要做远方的忠诚的儿子
 和物质的短暂情人
 和所有以梦为马的诗人一样
 我不得不和烈士和小丑走在同一道路上
此时的我就是没有物质的穷人，所以急于摆脱一个月光族的称呼，换上一副短暂情人的马甲。生活的重担已经开始碾压岁月，你狂奔在路上寻找你的梦，骑上你的马。巨轮开始碾过你的时候，你倒下了。为何我弱不禁风，一无是处。是啊，人们所有的愤怒都是来自于对自己无能的无奈。
<br /><br />
我们在生活的追赶下，寻找以梦为马
<br /><br />
多好啊，我的梦就是我的马，我带着他往前跑，追赶。记录到现在发现，我的故事总是断章取义，片段不全，无法完整的说明白一件事情。如何转述一个故事，如何记录一段有趣的过往，聊天的时候你发现朋友的智慧你能学到吗。问题总比答案多的日子，脑筋经常倒在了碗里。
<br /><br />
我身边的朋友有辍学创业的，有孜孜不倦升学考研的，但很少有人可以脱离这个世界，骑在马上追梦。可能这也是为何我总感觉无法落笔的原因，因为我从来没有遇到过这样的人值得纪念。如果真的要记录，让我想想该记录谁的过往，像一场电影。确实没有，我作为一个生活在每日算计的商人环境的人，每天耳濡目染的是各种神奇的商业战术，商业诈术。我想我应该把心放低，真正那些以梦为马的人应该是在市井，在山林，在人迹罕至，在熙攘的街头角落。
<br /><br />
我的生活确实太无趣了，我远离了爱情，却浪费着最美的青春的日子。经常告诉自己和家人，我在努力奋斗，等我等我。未来谁不害怕，一个人的日子，没了诗人的情怀，被生活的巨轮压了一次。有机会坐在一家街边小店，如果不为生计，那么一定就是那个以梦为马的人吧。梦想一定会被嘲笑，因为本身他的属性里就包含了荒诞和脱离。以梦为马的人，我会来找寻你们的，我感觉我一点点的获得了一些基因和力量。诗人的时代已经很久不复了，现在都是歌者的天下。当街头巷尾的音乐响起，我想大声吟诵诗一首。
<br /><br />
“酒是黄昏时归乡的小路”
<br />
“山寺寻桂子，诗酒趁年华”
<br />
“蒹葭苍苍，白露为霜”
<br />
……
<br />
此刻的我还不能上路，因为我仍然懦弱，因为我依然留恋。<br /><br />

大风起兮云飞扬，大丈夫生于安乐，怎可安乐待死。
<br /><br />
以梦喂马，以梦为马！
                </p>
                <div class="zan">
                    <i class="fa fa-heart fa-3"></i>
                </div>
            </div>
        </div>
        <div class="footer">
            <ul class="links">
                <li>友情链接：</li>
                <li><a href="GDL" target="blank">GDL的小站</a></li>
                <li><a href="http://www.liminghang.cn" target="blank" >李明航的小站</a></li>
            </ul>
            <div class="copyright">
                Copyright &copy; 2015 <a href="http://www.suuzee.cn">SU_ZE__' Blog</a> | <a href="http://www.miitbeian.gov.cn/">黑ICP备15001607号</a>
            </div>
            <div class="follow">
                关注我： <a href="http://weibo.com/2315975171" target="blank"><i class="fa fa-weibo"></i></a>&nbsp;
                <button><i class="fa fa-weixin"></i></button>
            </div>
        </div>
        <script src="js/jquery-1.11.2.min.js"></script>
        <script src="js/common.js"></script>
        <script src="prettify/prettify.js"></script>
        <script>
            $(function(){
                var someHeight = $(".article").css("height");
                $(".rightbar").height((parseInt(someHeight) + 51) + "px");
            });
        </script>
    </body>
</html>