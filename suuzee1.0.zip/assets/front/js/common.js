$(function(){
    $(".follow button").on("click", function(){
        $(".wechat").fadeIn();
    });
    $(".weixin i").on("click", function(){
        $(".wechat").fadeOut();
    });
    $(".wechat").on("click", function(){
        $(".wechat").fadeOut();
    });
});