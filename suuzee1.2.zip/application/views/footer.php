<div class="footer">
	<ul class="links">
		<li>友情链接：</li>
		<li><a href="http://blog.csdn.net/gdl116929569" target="blank">GDL的小站</a></li>
		<li><a href="http://blog.csdn.net/wei_chen666" target="blank" >SIX_GOD的小站</a></li>
		<li><a href="http://www.liminghang.cn" target="blank" >李明航的小站</a></li>
	</ul>
	<div class="copyright">
		Copyright &copy; 2015 <a href="http://www.suuzee.cn" target="blank">SU_ZE__' Blog</a> | <a href="http://www.miitbeian.gov.cn/" target="blank">黑ICP备15001607号</a>
	</div>
</div>
<div class="follow">
	关注我： <a href="http://weibo.com/2315975171" target="blank"><i class="fa fa-weibo"></i></a>&nbsp;
	<button><i class="fa fa-weixin"></i></button>
</div>